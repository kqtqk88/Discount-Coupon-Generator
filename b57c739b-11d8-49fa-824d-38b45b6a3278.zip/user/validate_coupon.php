
<?php

include 'callAPI.php';
include 'admin_token.php';

$baseUrl = getMarketplaceBaseUrl();
$admin_token = getAdminToken();
$userToken = $_COOKIE["webapitoken"];
$customFieldPrefix = getCustomFieldPrefix();

$contentBodyJson = file_get_contents('php://input');
$content = json_decode($contentBodyJson, true);
$order_guid = $content['order_guid'];

//TODO:: Validate if the current ORDER ID exists, UPDATE ?? SAVE
//========================================================================VALIDATE IF ORDER ID EXISTS=======================================================================
$order_exists = array(array('Name' => 'OrderId', "Operator" => "in",'Value' => $order_guid));
$url =  $baseUrl . '/api/v2/plugins/'. getPackageID() .'/custom-tables/Orders';
$couponDetails =  callAPI("POST", $admin_token['access_token'], $url, $order_exists);
//echo json_encode(['result' => $couponDetails['Records']]);
 error_log(json_encode($couponDetails));
 $rec = json_encode($couponDetails['Records']);
 error_log($rec);
    if ($rec == '[]') {
        error_log('no, i dont exists,');
        // $couponCode = '';
        // $order_details = array('OrderId' => $order_guid, 'CouponCode' => $coupon_name, 'DiscountValue' => $coupon_value);
        // //3. Save the Coupon details along with the fetched campaign ID
        // $url =  $baseUrl . '/api/v2/plugins/'. getPackageID() .'/custom-tables/Orders/rows';
        // $result =  callAPI("POST",$admin_token['access_token'], $url, $order_details);
        // error_log($url);
        // error_log(json_encode($result));
        // $log_file = "error.log"; 
        // // logging error message to given log file 
        // error_log(json_encode($result), 3, $log_file); 
    }else{
        $curr_order_id = json_encode($couponDetails['Records'][0]['Id']);
        //get the coupon value of the current 
        $curr_coupon_code = json_encode($couponDetails['Records'][0]['CouponCode']);
        $curr_coupon_code = str_replace('"', '', $curr_coupon_code); 
        error_log('current ' . $curr_coupon_code);
        $curr_orderid = str_replace('"', '', $curr_order_id); 

        error_log($curr_orderid);
        //update 
        //check if the coupon code is redeemable
        $coupon_details = array(array('Name' => 'CouponCode', 'Value' => $curr_coupon_code));
        $url =  $baseUrl . '/api/v2/plugins/'. getPackageID() .'/custom-tables/Coupon';
        $coupondetails1 =  callAPI("POST", $admin_token['access_token'], $url, $coupon_details);
        error_log('coupon details ' . json_encode($coupondetails1));
        //get qty and max redeem values,then compare
        //$coup_qty = json_encode($coupondetails['Records'][0]['Quantity']);
       /// error_log($coup_qty);
        //$coup_maxredeem = json_encode($coupondetails['Records'][0]['MaxRedeem']);
       /// error_log($coup_maxredeem);
        echo json_encode(['result' => $coupondetails1['Records']]);

        // error_log('yes i exists, just update the coupon code and discount value!');
        // $update_details = array('CouponCode' => $coupon_name, 'DiscountValue' => $coupon_value);
        // $url =  $baseUrl . '/api/v2/plugins/'. getPackageID() .'/custom-tables/Orders/rows/'. $curr_orderid;
        // $result =  callAPI("PUT",$admin_token['access_token'], $url, $update_details);
        // error_log($url);
        // error_log(json_encode($result));
        // error_log('updated');
    }
    ?>