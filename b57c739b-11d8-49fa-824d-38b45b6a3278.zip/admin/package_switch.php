<?php
include 'callAPI.php';
include 'admin_token.php';
$contentBodyJson = file_get_contents('php://input');
$content = json_decode($contentBodyJson, true);
$couponId = $content['couponId'];
$redeemswitch = $content['status'];
error_log('value'  . $redeemswitch);

$baseUrl = getMarketplaceBaseUrl();
$admin_token = getAdminToken();
$customFieldPrefix = getCustomFieldPrefix();

// to edit the records
// PUT http://..../api/v2/plugins/..../custom-tables/..../rows/{id of the records}
// Body is a json

//   {
//       "column name defined in dashboard": "value of the column",
//       ....
//   }
$isenabled = array('IsEnabled' => $redeemswitch);
//3. Save the Coupon details along with the fetched campaign ID
$url =  $baseUrl . '/api/v2/plugins/'. getPackageID() .'/custom-tables/Coupon/rows/'. $couponId;
$result =  callAPI("PUT",$admin_token['access_token'], $url, $isenabled);
error_log($url);
error_log(json_encode($result));

?>